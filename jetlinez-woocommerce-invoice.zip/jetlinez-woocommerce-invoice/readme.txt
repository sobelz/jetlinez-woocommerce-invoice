=== Jetlinez Invoice for WooCommerce ===
Contributors: jetlinez
Tags: woocommerce, whatsapp, invoice, pdf, jetlinez, order status
Requires at least: 6.2
Requires PHP: 7.4
WC requires at least: 7.0
Stable tag: 1.9.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

ارسال خودکار پیام وضعیت، فاکتور PDF و گزارش‌های روزانه و هفتگی سفارش‌های ووکامرس از طریق WhatsApp API جتلاینز.

== Description ==

این افزونه با تغییر سفارش به هرکدام از وضعیت‌های انتخاب‌شده در تنظیمات، پیام سفارش و فاکتور را برای شماره‌های تعیین‌شده از طریق Jetlinez ارسال می‌کند.

در صورت فعال بودن PeproDev Ultimate Invoice، افزونه PDF فاکتور را تولید می‌کند، ابتدا آن را در endpoint مدیای Jetlinez آپلود می‌کند و سپس شناسه mediaId را برای ارسال فایل به endpoint واتساپ می‌فرستد.

اگر در حالت «متن و فایل» افزونه فاکتور فعال نباشد، تولید/آپلود PDF شکست بخورد یا ارسال نهایی سند ممکن نشود، اطلاعات سفارش با قالب جایگزین متنی ارسال می‌شود. حالت «فقط فایل» هیچ پیام متنی جایگزینی نمی‌فرستد.

ویژگی‌های اصلی:

* پنل تنظیمات کامل در WooCommerce > Jetlinez WhatsApp
* احراز هویت با هدر X-API-KEY
* انتخاب چندگانه از همه وضعیت‌های اصلی و سفارشی ووکامرس برای ارسال خودکار
* تفکیک شماره‌های گیرندگان فاکتور، گیرندگان گزارش و شماره صورتحساب مشتری
* انتخاب مستقل «عدم ارسال»، «فقط متن»، «فقط فایل» یا «متن و فایل» برای هر وضعیت و هر نوع گیرنده
* نرمال‌سازی شماره‌های فارسی، عربی و بین‌المللی
* تولید PDF با متد عمومی PeproDev Ultimate Invoice
* آپلود multipart/form-data با فیلد file
* ارسال متن و PDF در دو پیام مستقل
* قالب‌های قابل ویرایش با متغیرهای سفارش
* جلوگیری از ارسال تکراری برای هر وضعیت و گیرنده
* صف Action Scheduler، با جایگزین WP-Cron
* گزارش روزانه واتساپ با انتخاب بازهٔ شناور ۲۴ ساعته یا روز تقویمی کامل گذشته، ساعت و اجزای قابل تنظیم
* گزارش هفتگی واتساپ با روز، ساعت، ۹ بخش قابل تنظیم و ارسال فوری گزارش ۷ روز کامل گذشته
* نمودار میله‌ای JPG تغییر فروش هفتگی با QuickChart و fallback مستقل به متن
* Retry نمایی برای خطاهای موقت API
* ثبت نتیجه در Order Notes و WooCommerce Logs
* اکشن ارسال/ارسال مجدد دستی در صفحه سفارش
* سازگار با HPOS از طریق WooCommerce CRUD
* امکان تعریف اطلاعات حساس در wp-config.php

== Installation ==

1. فایل ZIP افزونه را از مسیر Plugins > Add New > Upload Plugin نصب و فعال کنید.
2. WooCommerce باید فعال باشد.
3. برای PDF، افزونه PeproDev Ultimate Invoice را نصب و فعال کنید. نبودن آن مانع ارسال متنی نمی‌شود.
4. به WooCommerce > Jetlinez WhatsApp بروید.
5. Base URL را روی `https://my.jetlinez.com/api/v1` قرار دهید.
6. API Key و Device ID دستگاه واتساپ متصل را وارد کنید.
7. گیرندگان فاکتور، گیرندگان مستقل گزارش، کد کشور و وضعیت‌های محرک را تنظیم کنید.
8. ابتدا با بخش «ارسال پیام آزمایشی» اتصال را بررسی کنید.
9. گزینه «فعال‌سازی ارسال خودکار» را روشن و تنظیمات را ذخیره کنید.
10. در صورت نیاز، ساعت، نوع بازه و اجزای «گزارش روزانه واتساپ» را انتخاب و دکمه ارسال فوری گزارش ۲۴ ساعت گذشته را اجرا کنید.
11. برای گزارش هفتگی، روز و ساعت ارسال و شاخص‌های موردنیاز را انتخاب کنید؛ همه شاخص‌ها در نصب جدید به‌صورت پیش‌فرض فعال‌اند.

== Frequently Asked Questions ==

= چرا متن و PDF دو پیام جدا هستند؟ =

در مسیر ارسال document جتلاینز، متن به‌عنوان caption سند منتقل نمی‌شود. افزونه برای جلوگیری از حذف متن، پیام وضعیت را جداگانه و سپس فایل PDF را ارسال می‌کند.

= اگر Ultimate Invoice نصب نباشد چه می‌شود؟ =

برای مسیرهای «متن و فایل»، قالب جایگزین متنی شامل وضعیت، مشتری، اقلام، روش پرداخت/ارسال و مبلغ سفارش ارسال می‌شود. مسیر «فقط فایل» ناموفق ثبت می‌شود و متن جایگزین نمی‌فرستد؛ مسیر «فقط متن» نیز بدون نیاز به Ultimate Invoice ادامه می‌یابد.

= شماره‌ها با چه فرمتی وارد شوند؟ =

فرمت پیشنهادی E.164 بدون علامت مثبت است؛ برای نمونه `989121234567`. شماره `09121234567` نیز با کد کشور پیش‌فرض 98 به همین قالب تبدیل می‌شود. ارقام فارسی و عربی نیز پشتیبانی می‌شوند.

= لاگ‌ها کجا هستند؟ =

WooCommerce > Status > Logs و سپس منبع `jetlinez-invoice` را انتخاب کنید. API Key در لاگ ثبت نمی‌شود.

= گزارش روزانه چه داده‌هایی را می‌فرستد؟ =

فروش خالص، تعداد سفارش‌ها، میانگین سفارش‌های پرداخت‌شده، مشتریان یکتای دارای اولین سفارش پرداخت‌شده، سفارش‌های لغو/بازپرداخت/رهاشده و محصولاتی که بر اثر فروش‌های همان بازه ناموجود شده‌اند. محصولات از قبل ناموجود یا فقط کم‌موجود در این بخش تکرار نمی‌شوند. هر بخش از پنل قابل غیرفعال‌کردن است و گزارش از همان دستگاه واتساپ و فهرست مستقل گیرندگان گزارش استفاده می‌کند. نوع بازهٔ ارسال خودکار قابل انتخاب است: بازهٔ شناور ۲۴ ساعت گذشته، یا کل روز تقویمی قبل از ۰۰:۰۰ تا ۲۳:۵۹. در حالت روز کامل، فروش با روز کامل قبل از آن مقایسه می‌شود. دکمه ارسال فوری مستقل از این تنظیم، همین شاخص‌ها را برای ۲۴ ساعت گذشته محاسبه و با ۲۴ ساعت قبل از آن مقایسه می‌کند.

تعریف مشتری جدید در گزارش روزانه و هفتگی یکسان است: مشتری‌ای که پیش از شروع بازه سفارش پرداخت‌شده نداشته باشد. مشتریان مهمان با ایمیل صورتحساب و در نبود آن با شماره تلفن تطبیق داده می‌شوند.

سفارش رهاشده یعنی سفارش ناموفق یا سفارش در انتظار پرداختی که از مهلت نگهداری موجودی ووکامرس قدیمی‌تر است؛ در صورت غیرفعال‌بودن آن مهلت، ۶۰ دقیقه استفاده می‌شود. WP-Cron در اولین بازدید بعد از ساعت تعیین‌شده اجرا می‌شود.

= چگونه اطلاعات API را خارج از دیتابیس نگه دارم؟ =

ثابت‌های زیر را در wp-config.php تعریف کنید. فیلدهای متناظر در پنل قفل می‌شوند:

`define( 'JLWI_API_BASE_URL', 'https://my.jetlinez.com/api/v1' );`
`define( 'JLWI_API_KEY', 'YOUR_API_KEY' );`
`define( 'JLWI_DEVICE_ID', 'YOUR_DEVICE_ID' );`

= گزارش هفتگی شامل چه مواردی است؟ =

مجموع فروش و تغییر نسبت به هفته قبل، تعداد سفارش و میانگین ارزش سفارش، فروش روزانه، مشتری جدید در برابر تکراری، محصولات پرفروش/کم‌فروش، بیشترین رشد/افت فروش محصول، لغو/مرجوعی/پرداخت ناموفق و تخفیف استفاده‌شده. هر بخش مستقل از پنل قابل خاموش‌کردن است.

این گزارش ۷ روز تقویمی کامل گذشته را پوشش می‌دهد و آن را با ۷ روز پیش از آن مقایسه می‌کند. روز پیش‌فرض ارسال شنبه است؛ بنابراین در تنظیم پیش‌فرض، شنبه تا جمعهٔ قبل گزارش می‌شود. مشتری جدید، مشتری‌ای است که پیش از شروع بازه سفارش پرداخت‌شده نداشته باشد.

با فعال‌بودن بخش رشد/افت، یک نمودار دوستونی JPG نیز از QuickChart دریافت و از مسیر مدیای جتلاینز ارسال می‌شود. هفته قبل با شاخص پایه ۱۰۰ و هفته جاری با شاخص نسبی نمایش داده می‌شود. فقط شاخص‌های نسبی، درصد تغییر و کد ارز در درخواست نمودار قرار می‌گیرد و هیچ مبلغ فروش، اطلاعات فروشگاه، سفارش، محصول، مشتری، گیرنده یا کلید API به QuickChart فرستاده نمی‌شود. هر خطای دریافت، اعتبارسنجی، آپلود یا ارسال نمودار به ارسال صرفاً متنی برمی‌گردد.

= چگونه فاکتور را از افزونه دیگری تأمین کنم؟ =

با فیلتر `jlwi_invoice_file_path` یک مسیر مطلق و خواندنی به فایل PDF برگردانید. برای اعلام موقت بودن فایل و حذف آن پس از پردازش، فیلتر `jlwi_custom_invoice_is_temporary` را true کنید.

== Template placeholders ==

`{order_id}`، `{order_number}`، `{status}`، `{status_slug}`، `{previous_status}`، `{previous_status_slug}`، `{customer_name}`، `{customer_first_name}`، `{customer_last_name}`، `{customer_phone}`، `{customer_email}`، `{order_total}`، `{currency}`، `{order_date}`، `{payment_method}`، `{shipping_method}`، `{billing_address}`، `{shipping_address}`، `{customer_note}`، `{items}`، `{item_count}`، `{site_name}`، `{site_url}`، `{admin_email}`، `{invoice_note}`، `{invoice_available}` و `{recipient}`.

== Developer filters ==

* `jlwi_invoice_file_path`
* `jlwi_custom_invoice_is_temporary`
* `jlwi_order_recipients`
* `jlwi_max_recipients_per_order`
* `jlwi_normalized_phone`
* `jlwi_template_tokens`
* `jlwi_rendered_message`
* `jlwi_http_request_args`
* `jlwi_daily_report_recipients`
* `jlwi_daily_report_data`
* `jlwi_daily_report_message`
* `jlwi_daily_report_order_query_args`
* `jlwi_daily_report_inventory_attention`
* `jlwi_daily_report_abandoned_after_minutes`
* `jlwi_report_previous_customer_query_args`
* `jlwi_report_customer_is_new`
* `jlwi_daily_report_previous_customer_query_args`
* `jlwi_daily_report_customer_is_new`
* `jlwi_daily_report_inventory_limit`
* `jlwi_max_daily_report_recipients`
* `jlwi_weekly_report_recipients`
* `jlwi_weekly_report_data`
* `jlwi_weekly_report_message`
* `jlwi_weekly_report_order_query_args`
* `jlwi_weekly_report_previous_customer_query_args`
* `jlwi_weekly_report_customer_is_new`
* `jlwi_weekly_report_product_limit`
* `jlwi_weekly_report_product_change_limit`
* `jlwi_max_weekly_report_recipients`
